"""
Personal Assistant MCP Server
Uses Hugging Face Inference API (no local model download needed).
Tools: AI chat, todo list, notes, datetime
"""

import json
import os
from datetime import datetime
from mcp.server.fastmcp import FastMCP
from huggingface_hub import InferenceClient

# --- Hugging Face Inference API ---
HF_TOKEN = os.environ.get("HF_TOKEN", "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")
client = InferenceClient(
    provider="novita",
    token=HF_TOKEN if HF_TOKEN else None,
)
chat_history: list[dict] = []

# --- Storage helpers ---
TODO_FILE = "todos.json"
NOTES_FILE = "notes.json"


def _load_json(path: str) -> list:
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return []


def _save_json(path: str, data: list):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# --- MCP Server ---
mcp = FastMCP(
    "PersonalAssistant",
    instructions="A personal assistant with AI chat, todos, notes, and datetime tools.",
)


# ========== TOOL: Chat with AI ==========
@mcp.tool()
def chat(message: str) -> str:
    """Chat with the AI assistant. Send a message and get a conversational response."""
    global chat_history

    chat_history.append({"role": "user", "content": message})

    # Keep history manageable (last 10 exchanges)
    trimmed = chat_history[-20:]

    # Build context from real data
    context_parts = ["You are a helpful personal assistant. Be concise and friendly.",
                     "You have access to the user's real data below. ONLY reference this data. NEVER make up tasks or notes."]

    todos = _load_json(TODO_FILE)
    if todos:
        pending = [t for t in todos if not t["done"]]
        done = [t for t in todos if t["done"]]
        todo_lines = []
        for t in pending:
            todo_lines.append(f"  - #{t['id']} [{t['priority']}] {t['task']}")
        for t in done:
            todo_lines.append(f"  - #{t['id']} [DONE] {t['task']}")
        context_parts.append("USER'S TODOS:\n" + "\n".join(todo_lines))
    else:
        context_parts.append("USER'S TODOS: Empty - no tasks yet.")

    notes = _load_json(NOTES_FILE)
    if notes:
        note_lines = [f"  - #{n['id']} {n['title']}" for n in notes]
        context_parts.append("USER'S NOTES:\n" + "\n".join(note_lines))
    else:
        context_parts.append("USER'S NOTES: Empty - no notes yet.")

    now = datetime.now()
    context_parts.append(f"CURRENT TIME: {now.strftime('%A, %B %d, %Y %I:%M %p')}")

    system_prompt = "\n\n".join(context_parts)

    messages = [
        {"role": "system", "content": system_prompt},
        *trimmed,
    ]

    try:
        response = client.chat_completion(
            model="meta-llama/Llama-3.1-8B-Instruct",
            messages=messages,
            max_tokens=256,
        )
        reply = response.choices[0].message.content
        chat_history.append({"role": "assistant", "content": reply})
        return reply
    except Exception as e:
        return f"Chat error: {e}\n\nMake sure HF_TOKEN env variable is set with your Hugging Face token."


@mcp.tool()
def reset_chat() -> str:
    """Reset the chat conversation history to start fresh."""
    global chat_history
    chat_history = []
    return "Chat history cleared. Starting fresh!"


# ========== TOOL: To-Do List ==========
@mcp.tool()
def add_todo(task: str, priority: str = "medium") -> str:
    """Add a new task to your to-do list. Priority can be: low, medium, high."""
    todos = _load_json(TODO_FILE)
    todo = {
        "id": len(todos) + 1,
        "task": task,
        "priority": priority,
        "done": False,
        "created": datetime.now().isoformat(),
    }
    todos.append(todo)
    _save_json(TODO_FILE, todos)
    return f"Added todo #{todo['id']}: '{task}' (priority: {priority})"


@mcp.tool()
def list_todos(show_done: bool = False) -> str:
    """List all to-do items. Set show_done=True to include completed tasks."""
    todos = _load_json(TODO_FILE)
    if not todos:
        return "Your to-do list is empty!"

    filtered = todos if show_done else [t for t in todos if not t["done"]]
    if not filtered:
        return "No pending tasks. You're all caught up!"

    lines = []
    for t in filtered:
        status = "[x]" if t["done"] else "[ ]"
        lines.append(f"{status} #{t['id']} [{t['priority'].upper()}] {t['task']}")
    return "\n".join(lines)


@mcp.tool()
def complete_todo(todo_id: int) -> str:
    """Mark a to-do item as completed by its ID."""
    todos = _load_json(TODO_FILE)
    for t in todos:
        if t["id"] == todo_id:
            t["done"] = True
            _save_json(TODO_FILE, todos)
            return f"Completed: '{t['task']}'"
    return f"Todo #{todo_id} not found."


@mcp.tool()
def delete_todo(todo_id: int) -> str:
    """Delete a to-do item by its ID."""
    todos = _load_json(TODO_FILE)
    original_len = len(todos)
    todos = [t for t in todos if t["id"] != todo_id]
    if len(todos) < original_len:
        _save_json(TODO_FILE, todos)
        return f"Deleted todo #{todo_id}."
    return f"Todo #{todo_id} not found."


# ========== TOOL: Notes ==========
@mcp.tool()
def save_note(title: str, content: str) -> str:
    """Save a note with a title and content."""
    notes = _load_json(NOTES_FILE)
    note = {
        "id": len(notes) + 1,
        "title": title,
        "content": content,
        "created": datetime.now().isoformat(),
    }
    notes.append(note)
    _save_json(NOTES_FILE, notes)
    return f"Saved note #{note['id']}: '{title}'"


@mcp.tool()
def list_notes() -> str:
    """List all saved notes (titles only)."""
    notes = _load_json(NOTES_FILE)
    if not notes:
        return "No notes saved yet."
    lines = [f"#{n['id']} - {n['title']} ({n['created'][:10]})" for n in notes]
    return "\n".join(lines)


@mcp.tool()
def read_note(note_id: int) -> str:
    """Read the full content of a note by its ID."""
    notes = _load_json(NOTES_FILE)
    for n in notes:
        if n["id"] == note_id:
            return f"{n['title']}\n{'─' * 30}\n{n['content']}\n\nCreated: {n['created']}"
    return f"Note #{note_id} not found."


@mcp.tool()
def delete_note(note_id: int) -> str:
    """Delete a note by its ID."""
    notes = _load_json(NOTES_FILE)
    original_len = len(notes)
    notes = [n for n in notes if n["id"] != note_id]
    if len(notes) < original_len:
        _save_json(NOTES_FILE, notes)
        return f"Deleted note #{note_id}."
    return f"Note #{note_id} not found."


# ========== TOOL: Date & Time ==========
@mcp.tool()
def get_datetime() -> str:
    """Get the current date and time."""
    now = datetime.now()
    return now.strftime("Date: %A, %B %d, %Y\nTime: %I:%M:%S %p")


@mcp.tool()
def days_until(target_date: str) -> str:
    """Calculate days until a target date. Format: YYYY-MM-DD"""
    try:
        target = datetime.strptime(target_date, "%Y-%m-%d")
        delta = target - datetime.now()
        if delta.days < 0:
            return f"That date was {abs(delta.days)} days ago."
        elif delta.days == 0:
            return "That's today!"
        else:
            return f"{delta.days} days until {target_date}."
    except ValueError:
        return "Invalid date format. Please use YYYY-MM-DD."


# ========== Run Server ==========
if __name__ == "__main__":
    mcp.run(transport="stdio")
