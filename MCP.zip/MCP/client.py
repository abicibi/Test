"""
CLI Client for the Personal Assistant MCP Server.
Connects via stdio transport and lets you call tools interactively.
"""

import asyncio
import json
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    server_params = StdioServerParameters(
        command="python",
        args=["server.py"],
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # List available tools
            tools_result = await session.list_tools()
            tools = {t.name: t for t in tools_result.tools}

            print("\n🤖 Personal Assistant MCP Client")
            print("=" * 40)
            print("Available tools:")
            for name, tool in tools.items():
                print(f"  • {name}: {tool.description[:60]}...")
            print(f"\nType 'help' for commands, 'quit' to exit.\n")

            while True:
                try:
                    user_input = input("You > ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nGoodbye!")
                    break

                if not user_input:
                    continue
                if user_input.lower() in ("quit", "exit", "q"):
                    print("Goodbye!")
                    break
                if user_input.lower() == "help":
                    print("\nCommands:")
                    print("  chat <message>        - Talk to the AI")
                    print("  reset                 - Reset chat history")
                    print("  add <task> [priority] - Add a todo (priority: low/medium/high)")
                    print("  todos                 - List pending todos")
                    print("  done <id>             - Complete a todo")
                    print("  del-todo <id>         - Delete a todo")
                    print("  note <title> | <body> - Save a note (use | to separate)")
                    print("  notes                 - List all notes")
                    print("  read <id>             - Read a note")
                    print("  del-note <id>         - Delete a note")
                    print("  time                  - Get current date/time")
                    print("  until <YYYY-MM-DD>    - Days until a date")
                    print("  quit                  - Exit")
                    print()
                    continue

                # Parse and route commands
                try:
                    result = await route_command(session, user_input)
                    print(f"\n🤖 {result}\n")
                except Exception as e:
                    print(f"\n❌ Error: {e}\n")


async def route_command(session: ClientSession, user_input: str) -> str:
    parts = user_input.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    if cmd == "chat":
        if not arg:
            return "Please provide a message. Usage: chat <message>"
        result = await session.call_tool("chat", {"message": arg})
        return result.content[0].text

    elif cmd == "reset":
        result = await session.call_tool("reset_chat", {})
        return result.content[0].text

    elif cmd == "add":
        if not arg:
            return "Usage: add <task> [low|medium|high]"
        words = arg.rsplit(maxsplit=1)
        if len(words) == 2 and words[1] in ("low", "medium", "high"):
            task, priority = words
        else:
            task, priority = arg, "medium"
        result = await session.call_tool("add_todo", {"task": task, "priority": priority})
        return result.content[0].text

    elif cmd == "todos":
        show_done = arg.lower() == "all"
        result = await session.call_tool("list_todos", {"show_done": show_done})
        return result.content[0].text

    elif cmd == "done":
        if not arg.isdigit():
            return "Usage: done <todo_id>"
        result = await session.call_tool("complete_todo", {"todo_id": int(arg)})
        return result.content[0].text

    elif cmd.startswith("del-todo"):
        if not arg.isdigit():
            return "Usage: del-todo <todo_id>"
        result = await session.call_tool("delete_todo", {"todo_id": int(arg)})
        return result.content[0].text

    elif cmd == "note":
        if "|" not in arg:
            return "Usage: note <title> | <content>"
        title, content = arg.split("|", 1)
        result = await session.call_tool("save_note", {"title": title.strip(), "content": content.strip()})
        return result.content[0].text

    elif cmd == "notes":
        result = await session.call_tool("list_notes", {})
        return result.content[0].text

    elif cmd == "read":
        if not arg.isdigit():
            return "Usage: read <note_id>"
        result = await session.call_tool("read_note", {"note_id": int(arg)})
        return result.content[0].text

    elif cmd.startswith("del-note"):
        if not arg.isdigit():
            return "Usage: del-note <note_id>"
        result = await session.call_tool("delete_note", {"note_id": int(arg)})
        return result.content[0].text

    elif cmd == "time":
        result = await session.call_tool("get_datetime", {})
        return result.content[0].text

    elif cmd == "until":
        if not arg:
            return "Usage: until <YYYY-MM-DD>"
        result = await session.call_tool("days_until", {"target_date": arg})
        return result.content[0].text

    else:
        # Default: treat as chat
        result = await session.call_tool("chat", {"message": user_input})
        return result.content[0].text


if __name__ == "__main__":
    asyncio.run(main())
