#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PostgreSQL RDS connection utility
"""

import logging
import os
from typing import Optional, Any, Dict
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from contextlib import asynccontextmanager
from orm import Base

logger = logging.getLogger(__name__)

class PostgresRDS:
    """PostgreSQL RDS connection manager"""
    
    # SQ_NO_1.4 - Configure database connection parameters
    def __init__(self, database_url: str = ""):
        """
        Initialize PostgreSQL connection manager
        
        Args:
            database_url: Connection string for PostgreSQL database
        """
        if not database_url:
            database_url = os.getenv("DATABASE_URL", "postgresql+asyncpg://postgres:h[|Qt%o]LH0PeA~H@zeb-eus-ai-training-db.c9bhkrbqbcxt.us-east-1.rds.amazonaws.com:5432/Aug_Training")
        self.database_url = database_url
        
        self.engine = create_async_engine(
            self.database_url,
            echo=False,
            future=True,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10
        )
        self.async_session = sessionmaker(
            self.engine, 
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False
        )
    
    async def connect(self) -> None:
        """Connect to the database and verify connection"""
        try:
            async with self.engine.begin() as conn:
                await conn.run_sync(lambda _: None)
            logger.info("Database connection verified")
        except Exception as e:
            logger.error(f"Failed to connect to database: {str(e)}")
            raise
    
    async def create_tables(self) -> None:
        """Create database tables if they don't exist"""
        try:
            async with self.engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            logger.info("Database tables created or verified")
        except Exception as e:
            logger.error(f"Failed to create database tables: {str(e)}")
            raise
    
    @asynccontextmanager
    async def get_db(self):
        """
        Get a new database session context manager.
        
        Yields:
            AsyncSession: Database session.
        """
        
        logger.debug("Attempting to get a new database session.")
        async with self.async_session() as session:
            logger.debug("Database session created successfully.")
            yield session