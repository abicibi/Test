
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Document splitting utility
"""

import os
import fitz  # PyMuPDF
import docx
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path
from repository.errorlogrepository import ErrorLogRepository

logger = logging.getLogger(__name__)

class Splitter:
    """Document text extraction and splitting utility"""
    
    def __init__(self):
        """Initialize document splitter"""
        self.errorlog = ErrorLogRepository()
    
    #SS_SQ 1.15 - 1.16
    # input : {"file_path": "/path/file.pdf"}
    # output : Chunked document with page_no and content
    # functionality description : chunking its content.
    async def get_document_splits(self, file_path: str) -> Dict[int, str]:
        """
        Extract text from document and split into chunks by page
        
        Args:
            file_path: Path to the document file
            
        Returns:
            Dictionary mapping page numbers to text content
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        path = Path(file_path)
        file_extension = path.suffix.lower()
        
        docs_text = {}
        
        try:
            if file_extension == '.pdf':
                docs_text = await self._extract_pdf_text(file_path)
            elif file_extension == '.txt':
                docs_text = await self._extract_txt_text(file_path)
            elif file_extension == '.docx':
                docs_text = await self._extract_docx_text(file_path)
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
                
            return docs_text
            
        except Exception as e:
            await self.errorlog.log_error(chat_id = None, error_message = e)
            logger.error(f"Error extracting text from {file_path}: {str(e)}")
            raise
    
    async def _extract_pdf_text(self, file_path: str) -> Dict[int, str]:
        """Extract text from PDF document by page"""
        docs_text = {}
        
        try:
            with fitz.open(file_path) as doc:
                for page_no, page in enumerate(doc, 1):
                    document_text = page.get_text()
                    if document_text.strip():  # Skip empty pages
                        docs_text[page_no] = document_text
                        
            return docs_text
            
        except Exception as e:
            logger.error(f"Error extracting PDF text: {str(e)}")
            raise
    
    async def _extract_txt_text(self, file_path: str) -> Dict[int, str]:
        """Extract text from plain text file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
                
            # For text files, treat the whole content as a single page
            return {1: text} if text.strip() else {}
            
        except Exception as e:
            logger.error(f"Error extracting TXT text: {str(e)}")
            raise
    
    async def _extract_docx_text(self, file_path: str) -> Dict[int, str]:
        """Extract text from DOCX document"""
        try:
            doc = docx.Document(file_path)
            full_text = "\n".join([para.text for para in doc.paragraphs])
            
            # For DOCX files, treat the whole content as a single page
            return {1: full_text} if full_text.strip() else {}
            
        except Exception as e:
            logger.error(f"Error extracting DOCX text: {str(e)}")
            raise
