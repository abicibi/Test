#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AWS Bedrock embedding model utility
"""

import os
import json
import boto3
import logging
from typing import List, Dict, Any, Optional
from botocore.exceptions import ClientError
from repository.errorlogrepository import ErrorLogRepository

logger = logging.getLogger(__name__)

class BedrockEmbedding:
    """AWS Bedrock embedding model client"""
    
    def __init__(
        self, 
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        region_name: Optional[str] = None,
        model_id: str = "amazon.titan-embed-text-v1"
    ):
        """
        Initialize AWS Bedrock client
        
        Args:
            aws_access_key_id: AWS access key ID
            aws_secret_access_key: AWS secret access key
            region_name: AWS region name
            model_id: Bedrock model ID
        """
        self.aws_access_key_id = aws_access_key_id or os.getenv("AWS_ACCESS_KEY_ID","AKIAWSG4IKQBEDKSCBOH")
        self.aws_secret_access_key = aws_secret_access_key or os.getenv("AWS_SECRET_ACCESS_KEY", "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")
        self.region_name = region_name or os.getenv("AWS_REGION", "us-east-1")
        self.model_id = model_id

        self.errorlog = ErrorLogRepository()
        
        # Initialize AWS Bedrock client
        self.bedrock_runtime = boto3.client(
            service_name='bedrock-runtime',
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
            region_name=self.region_name
        )
        
        logger.info(f"Initialized AWS Bedrock client with model ID: {self.model_id}")
    
    #SS_SQ 1.23 - 1.25
    # input : chat_id and text.
    # output : Embeddings or Error.
    # functionality description : generating embeddings and returning it.
    async def embed(self, chat_id, text: str) -> List[float]:
        """
        Generate embedding vector for text using AWS Bedrock
        
        Args:
            text: Text to embed
            
        Returns:
            List of embedding vector values
        """
        if not text or not isinstance(text, str):
            raise ValueError("Text must be a non-empty string")
        
        # Truncate text if it's too long (model-specific limit)
        max_tokens = 8000  # Adjust based on model limits
        if len(text) > max_tokens * 4:  # Rough estimate of token count
            logger.warning(f"Text exceeds maximum token limit, truncating to ~{max_tokens} tokens")
            text = text[:max_tokens * 4]
        
        try:
            # Prepare request body
            request_body = json.dumps({
                "inputText": text
            })
            
            # Call AWS Bedrock API
            response = self.bedrock_runtime.invoke_model(
                modelId=self.model_id,
                contentType='application/json',
                accept='application/json',
                body=request_body
            )
            
            # Parse response
            response_body = json.loads(response.get('body').read())
            embedding = response_body.get('embedding')
            
            if not embedding:
                raise ValueError("No embedding returned from API")
            
            return embedding
            
        except Exception as e:
            error_message = f"Embedding generation failed: {str(e)}"
            await self.errorlog.log_error(chat_id, e)
            logger.error(error_message)
            raise RuntimeError(error_message)
