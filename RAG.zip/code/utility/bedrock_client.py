#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AWS Bedrock client utility for interacting with the Bedrock API.
"""
import uuid
import os
import boto3
import json
from fastapi import HTTPException
from repository.errorlogrepository import ErrorLogRepository

class BedrockClient:
    """AWS Bedrock client for generating embeddings and responses."""
    
    def __init__(self):
        """Initialize the Bedrock client."""
        self.client = boto3.client(
            'bedrock-runtime',
            aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID", "AKIAWSG4IKQBEDKSCBOH"),
            aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY", "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"),
            region_name=os.getenv("AWS_REGION", "us-east-1")
        )

        self.errorlog = ErrorLogRepository()
    
    async def invoke_model(self, chat_id: uuid.UUID, model_id: str = "us.amazon.nova-lite-v1:0", payload: dict = None):
        """Invoke a model on AWS Bedrock."""
        try:
            response = self.client.invoke_model( 
                modelId=model_id,
                body=json.dumps(payload)
            )
            response_body = json.loads(response.get("body").read())
        
            return response_body['output']['message']['content'][0]['text']
        except Exception as e:
            await self.errorlog.log_error(chat_id, e)
    
    def close_client(self):
        """Close the Bedrock client connection."""
        # No explicit close needed for boto3 clients, but can be added if necessary.
        pass
