#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Document controller for handling document-related API endpoints
"""

import logging
from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from service.embedding_service import EmbeddingService
from service.document_service import DocumentService
from repository.schema.request_schemas import FilePathRequest, DocumentResponse, ErrorResponse

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()

# Dependency injection for DocumentService
def get_document_service() -> DocumentService:
    """Dependency for document service"""
    from utility.bedrock_embedding import BedrockEmbedding
    from utility.postgres_rds import PostgresRDS
    from repository.document_repository import DocumentRepository
    from utility.splitter import Splitter
    
    db = PostgresRDS()
    embed_model = BedrockEmbedding()
    embedding_service = EmbeddingService(embed_model)
    document_repository = DocumentRepository(db)
    splitter = Splitter()
    
    return DocumentService(embedding_service, document_repository, splitter)

@router.post(
    "/documents/upload",
    response_model=DocumentResponse
)

#SS_SQ 1.7 - 1.50
# input : {"file_path": "/path/file.pdf"}
# output : status code with JSON containing document_ids and message, or error
# functionality description : Uploading a document using FastAPI, validating the file, chunking its content, generating embeddings, storing in the DB per chunk, and returning chunk IDs or error.
async def upload_document(
    request: FilePathRequest,
    document_service: DocumentService = Depends(get_document_service)
) -> Dict[str, Any]:
    """
    Upload and process document from file path
    
    Args:
        request: Request with file path
        
    Returns:
        Response with document IDs
    """
    try:
        # Validate file path and process document
        document_ids = await document_service.process_document(request.file_path)
        
        return {
            "document_ids": [str(doc_id) for doc_id in document_ids],
            "message": f"Document processed successfully with {len(document_ids)} chunks"
        }
        
    except HTTPException as e:
        raise e
    except Exception as e:
        error_message = f"Document upload failed: {str(e)}"
        logger.error(error_message)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_message
        )
