#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Chat controller for handling chat-related API endpoints.
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends
import uuid
from service.chatservice import ChatService
import os
from repository.schema.request_schemas import UserQuery

logger = logging.getLogger(__name__)
router = APIRouter()

def get_chat_service() -> ChatService:
    """Dependency injection for ChatService."""
    from utility.postgres_rds import PostgresRDS
    from repository.chatrepository import ChatRepository
    from repository.knowledgerepository import KnowledgeRepository
    from repository.responserepository import ResponseRepository
    from repository.errorlogrepository import ErrorLogRepository
    from service.embedding_service import EmbeddingService
    from utility.bedrock_embedding import BedrockEmbedding
    from service.llmservice import LLMService
    
    
    db_url = os.getenv("DATABASE_URL", "postgresql+asyncpg://postgres:h[|Qt%o]LH0PeA~H@zeb-eus-ai-training-db.c9bhkrbqbcxt.us-east-1.rds.amazonaws.com:5432/Aug_Training")
    
    db = PostgresRDS()
    
    return ChatService(
        ChatRepository(db),
        KnowledgeRepository(db),
        ResponseRepository(db),
        ErrorLogRepository(),
        EmbeddingService(BedrockEmbedding()),
        LLMService()
    )
    
#SS_SQ 2.3 - 2.105
# input : userquery and chatid
# output : status code with JSON containing answer, citation (page numbers), or error
# functionality description : Receiving a chat request via FastAPI, validating input, checking/creating chat session, identifying if question is about child psychology, deciding if chat history is needed, retrieving chat history if required, generating embedding for the query, searching for relevant knowledge base chunks, constructing a LLM prompt, querying Amazon Bedrock LLM, saving the response to the database, updating chat history, and returning answer/citation or error.
@router.post("/chat")
async def post_chat(user_query: UserQuery, chat_service: ChatService = Depends(get_chat_service)):
    """
    Handle incoming chat requests and process user queries.

    Args:
      user_query (UserQuery): The user's query input containing user_query and chat_id.

    Returns:
      ResponseModel containing the response to the user's query.
      
      Raises HTTPException if there are issues processing the request.
    """
    
    try:
        logger.info(f"Received query from user: {user_query.user_query} with chat_id: {user_query.chat_id}")
        
        if user_query.user_query is None or str(user_query.user_query).strip() is "":
            return{
                "status_code" : 422,
                "error": "Query cannot be empty."
            }

        # Process the user query through the ChatService
        response_model = await chat_service.process_query(chat_id=user_query.chat_id, query=user_query.user_query)
        
        return response_model
    
    except Exception as e:
        logger.error(f"Error processing chat request: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")