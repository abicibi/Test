#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LLM service for generating responses using Bedrock client.
"""

import logging
import uuid
from utility.bedrock_client import BedrockClient

logger = logging.getLogger(__name__)

class LLMService:

    def __init__(self):
       self.bedrock_client = BedrockClient()

    #SS_SQ 2.72 - 2.78
        # input : chat_id and prompt
        # output : llm reasponse or error
        # functionality description : formatted prompt used to LLM call and returing the response.
    async def generate_response(self, chat_id:uuid.UUID, prompt: str) -> str:
       return await self.bedrock_client.invoke_model(chat_id, payload =  prompt)
