#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Chat service for processing user queries and managing interactions with repositories.
"""

import logging
from uuid import UUID
import json
from repository.chatrepository import ChatRepository
from repository.knowledgerepository import KnowledgeRepository
from repository.responserepository import ResponseRepository
from repository.errorlogrepository import ErrorLogRepository
from service.llmservice import LLMService
from service.embedding_service import EmbeddingService

logger = logging.getLogger(__name__)

class ChatService:
    
    def __init__(self,
                 chat_repository: ChatRepository,
                 knowledge_repository: KnowledgeRepository,
                 response_repository: ResponseRepository,
                 error_repository: ErrorLogRepository,
                 embedding_service: EmbeddingService,
                 llm_service: LLMService):
        
        self.chat_repository = chat_repository
        self.knowledge_repository = knowledge_repository
        self.response_repository = response_repository
        self.error_repository = error_repository
        self.embedding_service = embedding_service
        self.llm_service = llm_service
    
    #SS_SQ 2.5 - 2.105
    # input : userquery and chatid
    # output : status code with JSON containing answer, citation (page numbers), or error
    # functionality description : Receiving a chat request via FastAPI, validating input, checking/creating chat session, identifying if question is about child psychology, deciding if chat history is needed, retrieving chat history if required, generating embedding for the query, searching for relevant knowledge base chunks, constructing a LLM prompt, querying Amazon Bedrock LLM, saving the response to the database, updating chat history, and returning answer/citation or error.
    async def process_query(self, chat_id: UUID, query: str):
        """
        Process the user query and return a response model.

        Args:
            chat_id (UUID): The ID of the chat session.
            query (str): The user's query.

        Returns:
            ResponseModel containing the response to the user's query.
        """
        
        logger.debug(f"Processing query: {query} for chat_id: {chat_id}")
        
        #SS_SQ 2.5 - 2.20
        # input : chatid
        # output : chatid
        # functionality description : Checking/creating chat session
        if chat_id is not None: 
            if not await self.chat_repository.exists(chat_id):
                logger.info(f"Chat ID {chat_id} does not exist. Creating new chat.")
                chat_id = await self.chat_repository.create_chat()
        
        else:
            logger.info(f"Creating new chat.")
            chat_id = await self.chat_repository.create_chat()

        #SS_SQ 2.21 - 2.28
        # input : userquery
        # output : Boolean
        # functionality description : Identifying if question is about child psychology.
        is_child_psychology_related = await self.identify_intention(chat_id, query)
        
        if str(is_child_psychology_related).lower() == "false":
            logger.info("Query is not related to child psychology.")
            
            return {"status_code": 400, "response": "Please ask questions related to child psychology."}
        
        #SS_SQ 2.33 - 2.51
        # input : userquery
        # output : Bool
        # functionality description : Deciding if chat history is needed, retrieving chat history if required.
        needs_history = await self.needs_chat_history(chat_id, query)
        
        if str(needs_history).lower() == "true":
            logger.debug("Chat history is needed for this query.")
            chat_history = await self.get_chat_history(chat_id)
            
        else:
            logger.debug("No chat history needed for this query.")
            chat_history = None

        #SS_SQ 2.58 - 2.65
        # input : userquery
        # output : embedding
        # functionality description : Generate embedding for the query using the embedding service.
        embedding = await self.embedding_service.generate_embedding(chat_id, query)
        
        #SS_SQ 2.58 - 2.65
        # input : embedding
        # output : Knowledge base object.
        # functionality description : Perform similarity search in knowledge base using the embedding.
        knowledge_entries = await self.knowledge_repository.similarity_search(embedding)

        #SS_SQ 2.66 - 2.71
        # input : query, knowledge_entries, and chat_history
        # output : formatted a prompt.
        # functionality description : formating a prompt for LLM call
        prompt = self.format_prompt(query, knowledge_entries, chat_history)
                
        # Generate response using LLM service.
        system_prompt = ("You are a professional child psychology assistant whose responses are always\n"
                        "accurate and concise. Rely solely on the information provided in the CONTEXT—do not\n"
                        "incorporate external facts, assumptions, or personal opinions. Respond directly to the\n"
                        "user’s QUESTION using confident and clear language. If the answer is not present in the CONTEXT,\n" 
                        "reply : 'No information available.' Don't add any another comments in it\n" 
                        "and cite relevant context snippets for every key point you make. Maintain a professional tone\n" 
                        "that is accessible to parents and caregivers while ensuring clarity and support.\n"
                        '**Important**: Do not add the user query and "According to the context" sentence in the answer, Assistant response alone')

        request_body = {
                        "schemaVersion": "messages-v1",
                        "messages" : [{

                            "role": "user",
                            "content": [{
                                "text": prompt
                            }]
                        }
                        ],
                        "system": [{
                            "text": system_prompt
                        }],
                        "inferenceConfig":{
                            "maxTokens": 500,
                            "temperature": 0.7
                        }
                    }

        llm_response = await self.llm_service.generate_response(chat_id, request_body)
       
        #SS_SQ 2.79 - 2.86
        # input : chat_id, query, response_text and citation
        # output : None
        # functionality description : Save response to database using response repository.
        context_str = "\n".join([f"Context: {context.content}" for context in knowledge_entries])
        page_no = "From the Page no :"+"\t".join([f"Context: {context.page_no}" for context in knowledge_entries])
        await self.response_repository.create_response(chat_id=chat_id, query=query, response_text=llm_response, citation=context_str)

        #SS_SQ 2.87 - 2.105
        # input : chat_id, and interactions
        # output : None
        # functionality description : Update the chat with the new interaction
        interactions = [{"user": query, "bot": llm_response}]
        await self.chat_repository.update_chat(chat_id, interactions)
        
        return {"status_code": 200, "response": llm_response, 'citation': page_no}

    #SS_SQ 2.23 - 2.27
    # input : userquery
    # output : Boolean
    # functionality description : Identifying if question is about child psychology.
    async def identify_intention(self, chat_id,  query: str) -> bool:
        """
            Identify if the query is related to child psychology.

            Args:
                query (str): The user's query.

            Returns:
                bool: True if related to child psychology, False otherwise.
        """
        system_prompt = (
            "You are a domain expert assistant specializing in child psychology.\n"
            "Your responses must be strictly limited to identifying whether a given question pertains to child psychology.\n"
            'Respond with "True" if the question is related to child psychology, and "False" if it is not.\n'
            "Do not provide explanations, additional information, or personal opinions."
        )
        
        request_body = {
                        "schemaVersion": "messages-v1",
                        "messages" : [{

                            "role": "user",
                            "content": [{
                                "text": query
                            }]
                        }
                        ],
                        "system": [{
                            "text": system_prompt
                        }],
                        "inferenceConfig":{
                            "maxTokens": 500,
                            "temperature": 0.7
                        }
                    }
        
        return await self.llm_service.generate_response(chat_id, request_body)

    
    #SS_SQ 2.35 - 2.39
        # input : userquery
        # output : Bool
        # functionality description : Deciding if chat history is needed, retrieving chat history if required.
    async def needs_chat_history(self, chat_id, query: str) -> bool:
        """
            Determine if chat history is needed based on the query.

            Args:
                query (str): The user's query.

            Returns:
                bool: True if chat history is needed, False otherwise.
        """

        system_prompt = ("You are a domain expert assistant responsible for evaluating Whether previous chat history is needed or not.\n"
                         "Your task is to determine if the chat history necessitates a response generation.\n"
                         'Respond with "True" if a response is needed based on the chat history, and "False" if it is not.\n'
                         "Do not provide explanations, additional information, or personal opinions.")

        request_body = {
                        "schemaVersion": "messages-v1",
                        "messages" : [{

                            "role": "user",
                            "content": [{
                                "text": query
                            }]
                        }
                        ],
                        "system": [{
                            "text": system_prompt
                        }],
                        "inferenceConfig":{
                            "maxTokens": 500,
                            "temperature": 0.7
                        }
                    }

        return await self.llm_service.generate_response(chat_id, request_body)

    #SS_SQ 2.33 - 2.51
        # input : userquery
        # output : Returing chat object of the particular id
        # functionality description : Retrieving chat history if required.
    async def get_chat_history(self, chat_id: UUID):
        return await self.chat_repository.get_chat(chat_id)

    #SS_SQ 2.66 - 2.71
        # input : query, knowledge_entries, and chat_history
        # output : formatted a prompt.
        # functionality description : formating a prompt for LLM call
    def format_prompt(self, query: str, contexts: list, chat_history: list) -> str:
        """
            Format the prompt for LLM based on user query and context from knowledge entries and chat history.

            Args:
                query (str): The user's query.
                contexts (list): Relevant knowledge entries.
                chat_history (list): Previous chat history.

            Returns:
                str: Formatted prompt for LLM.
        """  

        # Prepare context string from knowledge entries
        context_str = "\n".join([f"Context: {context.content}" for context in contexts])
        
        # Prepare chat history string
        if chat_history:
                if chat_history.text is not None:
                    content = json.loads(chat_history.text)
                    formatted = json.dumps(content, indent=4)
                    history_str = "\n".join([f"User: {entry['user']}\nAssistant: {entry['bot']}" for entry in content])
                    prompt = f"{history_str}\nUser: {query}\n{context_str}\nAssistant:"

                else:
                    prompt = f"User: {query}\n{context_str}\nAssistant:"
        else:
            prompt = f"User: {query}\n{context_str}\nAssistant:"
        
        logger.debug(f"Formatted prompt for LLM: {prompt}")
        return prompt
