#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Embedding service for generating text embeddings
"""

import logging
from typing import List, Dict, Any
from utility.bedrock_embedding import BedrockEmbedding
import uuid

logger = logging.getLogger(__name__)

class EmbeddingService:
    """Service for generating text embeddings"""
    
    def __init__(self, embed_model: BedrockEmbedding):
        """
        Initialize embedding service
        
        Args:
            embed_model: Embedding model implementation
        """
        self.embed_model = embed_model
        logger.info("Embedding service initialized")
    
    #SS_SQ 1.21 - 1.27 and 2.53 - 2.56
    # input : text
    # output : embeddings or error
    # functionality description : generating embeddings and returning it.
    async def generate_embedding(self, chat_id : uuid.UUID, text: str) -> List[float]:
        """
        Generate embedding vector for text
        
        Args:
            text: Text to embed
            
        Returns:
            List of embedding vector values
        """        
        try:
            # Call embedding model to generate embedding
            embedding = await self.embed_model.embed(chat_id, text)
            logger.debug(f"Generated embedding with {len(embedding)} dimensions")
            return embedding
        except Exception as e:
            error_message = f"Failed to generate embedding: {str(e)}"
            logger.error(error_message)
            raise RuntimeError(error_message)
