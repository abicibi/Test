#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Document processing service
"""

import os
import logging
from typing import List, Dict, Any, Set, Optional
from uuid import UUID
from pathlib import Path
from fastapi import HTTPException
from service.embedding_service import EmbeddingService
from repository.document_repository import DocumentRepository
from utility.splitter import Splitter

logger = logging.getLogger(__name__)

class DocumentService:
    """Service for document processing operations"""
    
    def __init__(
        self, 
        embedding_service: EmbeddingService,
        document_repository: DocumentRepository,
        splitter: Splitter
    ):
        """
        Initialize document service
        
        Args:
            embedding_service: Service for generating embeddings
            document_repository: Repository for document storage
            splitter: Document text extraction and splitting utility
        """
        self.embedding_service = embedding_service
        self.document_repository = document_repository
        self.splitter = splitter
        self.SUPPORTED_FORMATS = {'.pdf', '.txt', '.docx'}
        logger.info("Document service initialized")
    
    #SS_SQ 1.9 - 1.47
    # input : {"file_path": "/path/file.pdf"}
    # output : status code with JSON containing document_ids and message, or error
    # functionality description : Validating the file, chunking its content, generating embeddings, storing in the DB per chunk, and returning chunk IDs or error.
    async def process_document(self, file_path: str) -> List[UUID]:
        """
        Process document from file path
        
        Args:
            file_path: Path to document file
            
        Returns:
            List of document UUIDs generated
        """
        logger.info(f"Processing document: {file_path}")
        document_ids = []
        
        try:
            # Validate file path
            path = Path(file_path)
            if not path.exists():
                raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
            
            # Check file format
            if path.suffix.lower() not in self.SUPPORTED_FORMATS:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Unsupported file format: {path.suffix}. Supported formats: {', '.join(self.SUPPORTED_FORMATS)}"
                )
            
            # Get document name
            pdf_name = path.stem
            
            # Extract text from document
            docs_text = await self.splitter.get_document_splits(file_path)
            if not docs_text:
                raise HTTPException(status_code=400, detail="No text content found in document")
            
            # Process each page/chunk
            for page_no, content in docs_text.items():
                if not content.strip():
                    continue  # Skip empty content
                
                # Generate embedding for content
                embedding = await self.embedding_service.generate_embedding(content)
                
                # Store document in knowledge base
                document_id = await self.document_repository.add_document(
                    content=content,
                    embedding=embedding,
                    page_no=page_no,
                    pdf_name=pdf_name
                )
                document_ids.append(document_id)
                logger.info(f"Processed page {page_no} of {pdf_name}, document ID: {document_id}")
            
            if not document_ids:
                raise HTTPException(status_code=400, detail="Failed to process document content")
            
            return document_ids

        except Exception as e:
            error_message = f"Document processing failed: {str(e)}"
            logger.error(error_message)
            raise HTTPException(status_code=500, detail=error_message)
