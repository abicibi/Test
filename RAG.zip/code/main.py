#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Main application entry point for FastAPI document processing service and chat service.
"""

import os
import logging
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from controller.document_controller import router as document_router
from controller.chatcontroller import router as chat_router
from utility.postgres_rds import PostgresRDS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# SQ_NO_1.1 - Initialize FastAPI application with required dependencies
app = FastAPI(
    title="Document Processing API",
    description="API for 1. processing documents and generating embeddings\n2. chat interactions and knowledge base queries",
    version="1.0.0"
)

# Configure CORS
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

#SS_SQ 1.6 - 1.51
# input : {"file_path": "/path/file.pdf"}
# output : status code with JSON containing document_ids and message, or error
# functionality description : Uploading a document using FastAPI, validating the file, chunking its content, generating embeddings, storing in the DB per chunk, and returning chunk IDs or error.
app.include_router(
    document_router,
    prefix="/api/v1/ChatBot",
    tags=["documents"]
)

#SS_SQ 2.2 - 2.106
# input : userquery and chatid
# output : status code with JSON containing answer, citation (page numbers), or error
# functionality description : Receiving a chat request via FastAPI, validating input, checking/creating chat session, identifying if question is about child psychology, deciding if chat history is needed, retrieving chat history if required, generating embedding for the query, searching for relevant knowledge base chunks, constructing a LLM prompt, querying Amazon Bedrock LLM, saving the response to the database, updating chat history, and returning answer/citation or error.
app.include_router(
    chat_router,
    prefix="/api/v1/ChatBot",
    tags=["chat"]
)

# # SQ_NO_1.3 - Setup database connection
@app.on_event("startup")
async def startup_db_client():
    """Initialize database connection on application startup"""
    try:
        db_url = os.getenv("DATABASE_URL", "postgresql+asyncpg://postgres:h[|Qt%o]LH0PeA~H@zeb-eus-ai-training-db.c9bhkrbqbcxt.us-east-1.rds.amazonaws.com:5432/Aug_Training")
        db = PostgresRDS(db_url)
        await db.connect()
        await db.create_tables()
        logger.info("Database connection established successfully")
    except Exception as e:
        logger.error(f"Failed to connect to database: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown_db_client():
    """Close database connection on application shutdown"""
    # Connection pooling is handled by SQLAlchemy
    logger.info("Shutting down database connections")

@app.get("/health", tags=["health"])
async def health_check():
    """Health check endpoint to verify API is running"""
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    # Start server
    logger.info(f"Starting server on {host}:{port}")
    uvicorn.run("main:app", host=host, port=port, reload=True)
