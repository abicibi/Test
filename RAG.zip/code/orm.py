#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ORM base class for SQLAlchemy models.
"""

from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
