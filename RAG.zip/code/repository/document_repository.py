#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Document repository for database operations
"""

import uuid
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy import select
from repository.schema.knowledge import KnowledgeBase
from utility.postgres_rds import PostgresRDS

logger = logging.getLogger(__name__)

class DocumentRepository:
    """Repository for document database operations"""
    
    def __init__(self, db: PostgresRDS):
        """
        Initialize document repository
        
        Args:
            db: Database connection manager
        """
        self.db = db
        logger.info("Document repository initialized")
    
    #SS_SQ 1.39 - 1.43
    # input : content, embedding, page_no and pdf_name
    # output : document_id
    # functionality description : Store document content and embedding in database
    async def add_document(self, content: str, embedding: List[float], page_no: int, pdf_name: str) -> uuid.UUID:
        """
        Add document content and embedding to database
        
        Args:
            content: Document text content
            embedding: Embedding vector for content
            page_no: Page number in original document
            pdf_name: Name of the source PDF file
            
        Returns:
            UUID of the created document entry
        """
        if not content or not embedding:
            raise ValueError("Content and embedding must be provided")
            
        # Generate UUID for document
        document_id = uuid.uuid4()
        created_time = datetime.utcnow()
        
        try:
            # Create database session
            async with self.db.get_db() as session:
                # Create knowledge base entry
                knowledge_base_entry = KnowledgeBase(
                    id=document_id,
                    content=content,
                    embedding=embedding,
                    page_no=page_no,
                    pdf_name=pdf_name,
                    created_at=created_time
                )
                
                # Add entry to database
                session.add(knowledge_base_entry)
                await session.commit()
                
                logger.info(f"Added document to knowledge base with ID: {document_id}")
                return document_id
                
        except Exception as e:
            error_message = f"Failed to add document to database: {str(e)}"
            logger.error(error_message)
            raise RuntimeError(error_message)
    
    async def create_table(self) -> None:
        """Create knowledge base table if it doesn't exist"""
        try:
            # Tables are created in PostgresRDS.create_tables()
            logger.info("Knowledge base table creation handled by PostgresRDS")
        except Exception as e:
            logger.error(f"Failed to create knowledge base table: {str(e)}")
            raise
