#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Knowledge repository for managing knowledge base-related database operations.
"""

import logging

from sqlalchemy import select
from utility.postgres_rds import PostgresRDS
from repository.schema.knowledge import KnowledgeBase

logger = logging.getLogger(__name__)

class KnowledgeRepository:
    """Repository for managing knowledge base data."""
    
    def __init__(self, db: PostgresRDS):
        """
        Initialize KnowledgeRepository.
        
        Args:
            db: Database connection manager instance.
        """
        self.db = db
    
    #SS_SQ 2.59 - 2.64
        # input : embedding
        # output : Knowledge base object.
        # functionality description : Perform similarity search in knowledge base using the embedding.
    async def similarity_search(self, embedding: list, limit: int = 2) -> list:
        """Perform a similarity search in the knowledge base."""
        async with self.db.get_db() as session:
            stmt = (
                select(KnowledgeBase)
                .order_by(KnowledgeBase.embedding.op("<=>")(embedding))
                .limit(limit)
            )
            result = await session.execute(stmt)
            return result.scalars().all()
