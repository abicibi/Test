#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Chat repository for managing chat-related database operations.
"""

import uuid
import json
import logging
from sqlalchemy import select, update
from utility.postgres_rds import PostgresRDS
from repository.schema.chat import ChatModel
from datetime import datetime

logger = logging.getLogger(__name__)

class ChatRepository:
    """Repository for managing chat data."""
    
    def __init__(self, db: PostgresRDS):
        """
        Initialize ChatRepository.
        
        Args:
            db: Database connection manager instance.
        """
        self.db = db
    
    #SS_SQ 2.14 - 2.19
        # input : None
        # output : chatid
        # functionality description : Creating a new Chat
    async def create_chat(self) -> ChatModel:
        """Create a new chat entry in the database."""
        new_chat = ChatModel(chat_id=uuid.uuid4(), created_at=datetime.utcnow())
        
        async with self.db.get_db() as session:
            session.add(new_chat)
            await session.commit()
        
        logger.info(f"Created new chat with ID: {new_chat.chat_id}")
        return new_chat.chat_id
    
    #SS_SQ 2.6 - 2.11
        # input : chatid
        # output : Bool
        # functionality description : Checking chat exists or not
    async def exists(self, chat_id: uuid.UUID) -> bool:
        """Check if a chat exists by its ID."""
        async with self.db.get_db() as session:
            result = await session.execute(select(ChatModel).where(ChatModel.chat_id == chat_id))
            return result.scalars().first() is not None
    
    async def get_chat(self, chat_id: uuid.UUID) -> ChatModel:
        """Retrieve a chat by its ID."""
        async with self.db.get_db() as session:
            result = await session.execute(select(ChatModel).where(ChatModel.chat_id == chat_id))
            return result.scalars().first()

    #SS_SQ 2.97 - 2.103
    # input : chat_id, and interactions
    # output : None
    # functionality description : Update the chat with the new interaction
    async def update_chat(self, chat_id: uuid.UUID, interactions: list) -> ChatModel:
        """
        Update the chat text with new interactions.

        Args:
            chat_id (UUID): The ID of the chat to update.
            interactions (list): List of user-bot interactions.

        Returns:
            ChatModel: The updated chat object.
        """
        async with self.db.get_db() as session:
            # Retrieve the existing chat
            existing_chat = await self.get_chat(chat_id)
            
            if existing_chat:
                # Update the chat history with new interactions
                existing_chat.update_chat_history(interactions)
                
                stmt = update(ChatModel).where(ChatModel.chat_id == chat_id).values(text=existing_chat.text)
                await session.execute(stmt)
                await session.commit()
                
                logger.info(f"Updated chat with ID: {chat_id}")
                return await self.get_chat(chat_id)  # Return the updated chat
            
            else:
                logger.warning(f"Chat ID {chat_id} not found for update.")
                raise ValueError("Chat not found.")