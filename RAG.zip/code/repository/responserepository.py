
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Response repository for managing response-related database operations.
"""

import logging

from sqlalchemy import select
from utility.postgres_rds import PostgresRDS
from repository.schema.response import ResponseModel
import uuid

logger = logging.getLogger(__name__)

class ResponseRepository:
    """Repository for managing response data."""
    
    def __init__(self, db: PostgresRDS):
        """
        Initialize ResponseRepository.
        
        Args:
            db: Database connection manager instance.
        """
        self.db = db
    
    #SS_SQ 2.79 - 2.86
    # input : chat_id, query, response_text and citation
    # output : None
    # functionality description : Save response to database using response repository.
    async def create_response(self, chat_id: uuid.UUID, query: str, response_text: str, citation: str) -> ResponseModel:
        """Create a new response entry in the database."""
        new_response = ResponseModel(chat_id=chat_id, query=query, response_text=response_text, citation=citation)
        
        async with self.db.get_db() as session:
            session.add(new_response)
            await session.commit()
        
        logger.info(f"Created new response for chat ID: {chat_id}")
        return new_response
    
    async def get_chat_history(self, chat_id: uuid.UUID) -> list:
        """Retrieve the chat history for a given chat ID."""
        async with self.db.get_db() as session:
            result = await session.execute(select(ResponseModel).where(ResponseModel.chat_id == chat_id))
            return result.scalars().all()
