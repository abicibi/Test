#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Response schema for ORM mapping.
"""

from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from orm import Base
from datetime import datetime
import uuid

class ResponseModel(Base):
    """ORM model for storing responses to user queries."""
    
    __tablename__ = "crv_responses"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    chat_id = Column(UUID(as_uuid=True), ForeignKey('crv_chats.chat_id'))
    query = Column(String)
    response_text = Column(String)
    citation = Column(String)
    created_at = Column(DateTime, default = datetime.now())
