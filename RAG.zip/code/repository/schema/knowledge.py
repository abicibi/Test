#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Knowledge base ORM model for document storage
"""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, LargeBinary
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.ext.declarative import declarative_base
from pgvector.sqlalchemy import Vector

from orm import Base

class KnowledgeBase(Base):
    """Database model for storing document content and embeddings"""
    
    __tablename__ = "crv_knowledge_base"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    content = Column(String, nullable=False)
    embedding = Column(Vector(1536), nullable=False)  # Store embedding vector as JSONB
    page_no = Column(Integer, nullable=False)
    pdf_name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        """String representation of the knowledge base entry"""
        return f"<KnowledgeBase(id={self.id}, pdf_name={self.pdf_name}, page_no={self.page_no})>"
