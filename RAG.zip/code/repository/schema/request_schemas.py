#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Pydantic schemas for request/response validation.
"""

from typing import List, Dict, Any
from pydantic import BaseModel
from typing import Optional

import uuid

class FilePathRequest(BaseModel):
    """Schema for file path request."""
    
    file_path: str

class DocumentResponse(BaseModel):
    """Schema for successful response."""
    
    document_ids: List[str]
    message: str

class ErrorResponse(BaseModel):
    """Schema for error response."""
    
    detail: str

class UserQuery(BaseModel):
    """Schema for user query input."""

    user_query: str
    chat_id: Optional[uuid.UUID] = None

