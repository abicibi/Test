#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Chat schema for ORM mapping.
"""

from sqlalchemy import Column, String, DateTime, JSON, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from orm import Base
import json

class ChatModel(Base):
    """ORM model for storing chat data."""
    
    __tablename__ = "crv_chats"
    
    chat_id = Column(UUID(as_uuid=True), primary_key=True)
    text = Column(Text) 
    created_at = Column(DateTime)

    def get_chat_history(self):
        """Return chat history as a list of dictionaries."""
        return json.loads(self.text) if self.text else []

    def update_chat_history(self, interactions: list):
        """Update the chat history with new interactions."""
        current_history = self.get_chat_history()
        current_history.extend(interactions)
        self.text = json.dumps(current_history)
