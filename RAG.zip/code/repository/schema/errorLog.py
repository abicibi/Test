#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Error log schema for ORM mapping.
"""

from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from orm import Base
import uuid

class ErrorLogModel(Base):
    """ORM model for storing error logs related to chats."""
    
    __tablename__ = "crv_error_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    chat_id = Column(UUID(as_uuid=True), ForeignKey('crv_chats.chat_id'))
    error_message = Column(String)
    timestamp = Column(DateTime)
