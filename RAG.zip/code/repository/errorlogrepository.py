
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Error log repository for managing error log-related database operations.
"""

import logging
import uuid
from utility.postgres_rds import PostgresRDS
from repository.schema.errorLog import ErrorLogModel
from utility.postgres_rds import PostgresRDS

logger = logging.getLogger(__name__)

class ErrorLogRepository:
    """Repository for managing error log data."""
    
    def __init__(self):
        """
        Initialize ErrorLogRepository.
        
        Args:
            db: Database connection manager instance.
        """
        self.db = PostgresRDS()
    
    async def log_error(self, chat_id: uuid.UUID, error_message: str) -> ErrorLogModel:
        """Log an error entry in the database."""
        error_log = ErrorLogModel(chat_id=chat_id, error_message=error_message)
        
        async with self.db.get_db() as session:
            session.add(error_log)
            await session.commit()
        
        logger.error(f"Logged error for chat ID: {chat_id} - {error_message}")
        return error_log
